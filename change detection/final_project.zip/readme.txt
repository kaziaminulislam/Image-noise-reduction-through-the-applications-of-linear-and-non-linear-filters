# please copy all this file to matlab directory

# cdik_with_error_detection.m for CDIK method which also compute false alarm missed alarm
	overall erro and kappa index for varying alpha from 0-1. 
	It will also plot the outputs.

#cdik_sharmelshaikhdata.m for CDI K method for sharm-el-shaikh data for varying alpha 0-1.


#fuzzycmenas_kmeans_with_errordetection.m for fuzzy clustering and k-means method which also 
	compute false alarm missed alarm overall error and kappa index for varying alpha from 0-1.
	 It will also plot the outputs.

# fuzzycmeans_kmeans_sharmelshaikhdata.m for CDI K method for sharm-el-shaikh data for varying alpha 0-1.
